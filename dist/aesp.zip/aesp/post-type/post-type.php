<?php
require_once 'documento.php';
require_once 'associados.php';
require_once 'parceiros.php';